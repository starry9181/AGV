/**
  ******************************************************************************
  * @file    dealrosdata.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-09-05
  * @brief   ������λ�����ݣ�ͨ��Э��ע������ʵ��
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "dealrosdata.h"
#include "main.h"
#include "key_board.h"

union RespondRobotData20MS TXData20MS;
union RESMode1 TXMode1;
union RESMode2 TXMode2;
union ROBOTSTA RobotSta;
/**************************************************************************
�������ܣ�50ms���ص�������
��ڲ�������
����  ֵ����
**************************************************************************/
static u8 SendDataMode=0;//20ms�ϴ�ģʽ
void SendRobotDataToROS20ms(void)
{
	u8 i = 0;
	u16 TempCheck = 0;
	static s16 LTemEn=0,RTemEn=0;
	
	//��ȡ����
	RobotSta.err.stop  = STOP_READ;
	RobotSta.err.power = RobotState.bits.bit4;
	RobotSta.err.motor = RobotState.bits.bit0 | RobotState.bits.bit1 | RobotState.bits.bit2 | RobotState.bits.bit3;
	RobotSta.err.fronde = ~DELECTLEFT;
	RobotSta.err.backde = ~DELECTRIGHT;
	RobotSta.err.StopCon= RXRobotLedStop.prot.Stop;
	RobotSta.err.bit6 = Light1;
	RobotSta.err.bit7 = Light2;
	
	TXData20MS.prot.Header	= DATAHEAD;
	TXData20MS.prot.Len		= 0x30;
	TXData20MS.prot.Type	= 0x04;
	TXData20MS.prot.Cmd		= 0x81;
	TXData20MS.prot.Num		= 0x15;
	TXData20MS.prot.Check	= 0;
	
	if	   (SendDataMode== 1)
	{
		TXMode1.port.Vx = Odom.Vx;
		TXMode1.port.Vz = Odom.Vz;
		TXMode1.port.AccX = 0;//stcAcc.a[0]/2048.0;
		TXMode1.port.AccY = 0;//stcAcc.a[1]/2048.0;
		TXMode1.port.AccZ = 0;//stcAcc.a[2]/2048.0;
		TXMode1.port.GyrX = 0;//stcGyro.w[0]/939.21;
		TXMode1.port.GyrY = 0;//stcGyro.w[1]/939.21;
		TXMode1.port.GyrZ = 0;//stcGyro.w[2]/939.21;
		TXMode1.port.Voltage = PowerVale*10;
		TXMode1.port.State = RobotSta.data;
		TXMode1.port.Light12 = Led1Mode + (Led2Mode << 8);
		TXMode1.port.Light34 = 0;
		TXMode1.port.key_board_state = (((~TAKE_PINX_STATE_READ)&0x01) | (((~DISCHARGE_PINX_STATE_READ)<<1)&0x02)|(((~BATTERY_CHARGE_PINX_STATE_READ)<<2)&0x04)|(((~RESET_PINX_STATE_READ)<<3)&0x08))&0xff;
		for(i=0;i<sizeof(TXMode1.data);i++)
		{
			TXData20MS.prot.data[i] = TXMode1.data[i];
		}
		
	}
	else if(SendDataMode== 2)
	{
		TXMode2.port.LSpeed = LeftWheel. NowSpeed;
		TXMode2.port.RSpeed = RightWheel.NowSpeed;
		TXMode2.port.LAddEN = LTemEn - TIM3 -> CNT;;
		TXMode2.port.RAddEN = RTemEn + TIM5 -> CNT;;
		TXMode2.port.AccX =0;// stcAcc.a[0]/2048.0;
		TXMode2.port.AccY =0;// stcAcc.a[1]/2048.0;
		TXMode2.port.AccZ =0;// stcAcc.a[2]/2048.0;
		TXMode2.port.GyrX =0;// stcGyro.w[0]/939.21;
		TXMode2.port.GyrY = 0;//stcGyro.w[1]/939.21;
		TXMode2.port.GyrZ =0;// stcGyro.w[2]/939.21;
		TXMode2.port.Voltage = PowerVale*10;
		TXMode2.port.State = RobotSta.data;
		TXMode2.port.Light12 = Led1Mode + (Led2Mode << 8);
		TXMode2.port.Light34 = 0;
		TXMode2.port.key_board_state =  (((~TAKE_PINX_STATE_READ)&0x01) | (((~DISCHARGE_PINX_STATE_READ)<<1)&0x02)|(((~BATTERY_CHARGE_PINX_STATE_READ)<<2)&0x04)|(((~RESET_PINX_STATE_READ)<<3)&0x08))&0xff;
		for(i=0;i<sizeof(TXMode2.data);i++)
		{
			TXData20MS.prot.data[i] = TXMode2.data[i];
		}
	}
	
	for(i=0;i<sizeof(TXData20MS.data)-2;i++)
	{
		TempCheck +=  TXData20MS.data[i];
	}
	TXData20MS.prot.Check = TempCheck;
		
	USART2_DMA_TX(TXData20MS.data,sizeof(TXData20MS.data));
	//USART1_DMA_TX(TXData20MS.data,sizeof(TXData20MS.data));
	
	LTemEn = + TIM3 -> CNT;
	RTemEn = - TIM5 -> CNT;
	
}

/******************************����Ӳ������********************************************/
union SendHardData TXHardData;

void ResendHardData(void)
{
	u8 i = 0;
	u16 TempCheck = 0;
	
	TXHardData.prot.Header = DATAHEAD;
	TXHardData.prot.Len = 0x18;
	TXHardData.prot.Type = 0x04;
	TXHardData.prot.Cmd = 0x80;
	TXHardData.prot.Num = 0x08;
	TXHardData.prot.Version = 0x1002;
	TXHardData.prot.Power = 60;
	TXHardData.prot.Ratio = Wheel_RATIO_R;
	TXHardData.prot.Encoder = ENCODER_LINE;
	TXHardData.prot.XWheelbase = WHEELBASEX;
	TXHardData.prot.YWheelbase = WHEELBASEY;
	TXHardData.prot.WheelD = Wheel_D;
	TXHardData.prot.Battery = 20;
	TXHardData.prot.Check = 0;
	
	for(i=0;i<sizeof(TXHardData.data)-2;i++)
	{
		TempCheck +=  TXHardData.data[i];
	}
	TXHardData.prot.Check = TempCheck;
	
	USART2_DMA_TX(TXHardData.data,sizeof(TXHardData.data));
	//USART1_DMA_TX(TXHardData.data,sizeof(TXHardData.data));
}

/**************************************************************************
�������ܣh���ROS�·����ٶ�
��ڲ�����data
����  ֵ����
**************************************************************************/
union ReciveData RXRobotData;
union ReciveDataSpeed RXRobotSpeed;
union ReciveDataLedStop	RXRobotLedStop;

void RXRobotDataFromROS(u8 *data)
{
	static union 
	{
		u8  ChData[8];
		s16 InData[4];
		float FlData[2];
	}TempSpeed;
	
	u8 i=0;
	u16 TempCheck = 0;
	u8 ChargeControl = 0;
	for(i=0;i<sizeof(RXRobotData.data);i++)
	{
		RXRobotData.data[i] = data[i];
	}

	if(RXRobotData.prot.Header == DATAHEAD && RXRobotData.prot.Type == 0x04)
	{
		switch(RXRobotData.prot.Cmd)
		{
			case 0x00:	//��ѯӲ����Ϣ
			{
				for(i=0;i<sizeof(RXRobotData.data)-2;i++)
				{
					TempCheck += RXRobotData.data[i];
				}
				
				if(TempCheck == RXRobotData.prot.Check)
				{
					//����Ӳ����Ϣ
					ResendHardData();
				}
				break;
			}
			case 0x01:	//�������߹ر�20ms�ϴ�
			{
				for(i=0;i<sizeof(RXRobotData.data)-2;i++)
				{
					TempCheck += RXRobotData.data[i];
				}
				
				if(TempCheck == RXRobotData.prot.Check)
				{
					//����20ms�ϴ�ģʽ
					SendDataMode = RXRobotData.prot.data;
					
					if(SendDataMode)
					{
						//������ʱ��
						xTimerStart(AutoReloadTimer_Handle,0);
					}
					else
					{
						//�رն�ʱ��
						xTimerStop(AutoReloadTimer_Handle,0);
					}
				}
				break;
			}
			case 0x02:	//�����ٶ�����
			{
				for(i=0;i<sizeof(RXRobotSpeed.data);i++)
				{
					RXRobotSpeed.data[i] = data[i];
				}
				
				TempCheck =0;
				for(i=0;i<sizeof(RXRobotSpeed.data)-2;i++)
				{
					TempCheck += RXRobotSpeed.data[i];
				}
				
				if(TempCheck != RXRobotSpeed.prot.Check)
				{
					return;
				}
				
				for(i=0;i<sizeof(TempSpeed.ChData);i++)
				{
					TempSpeed.ChData[i] = RXRobotSpeed.prot.data[i];
				}
				
				//��ͣģʽ��
				if(RXRobotLedStop.prot.Stop == 1)
				{
					//��ͣ
					STOP2 = 0;
					STOP4 = 0;
					TempSpeed.FlData[0] = 0;
					TempSpeed.FlData[1] = 0;
				}
		
				
				//����ģʽ
				if	   (TempSpeed.InData[0] == 0)
				{
					//ң����ģʽ�»��߼�ͣ����¶��ٶ���0
					if((Mc6c.LeftKey == 2 || Mc6c.RightKey == 0) && Mc6c.DisconFlag == 0)
					{
						TempSpeed.FlData[0] = 0;
						TempSpeed.FlData[1] = 0;
					}
					RecRosDataTimeCnt = 0;
					
					if(Mc6c.LeftKey == 2 || DealTouchFlag == 1)
					{
						return;
					}
					
					SetAddLeftWheelSpeed (TempSpeed.InData[1] - TempSpeed.FlData[1]*WHEELBASEY/2);
					SetAddRightWheelSpeed(TempSpeed.InData[1] + TempSpeed.FlData[1]*WHEELBASEY/2);
				}
				//����ģʽ
				else if(TempSpeed.InData[0] == 1)
				{
					//ң����ģʽ�»��߼�ͣ����¶��ٶ���0
					if((Mc6c.LeftKey == 2 || Mc6c.RightKey == 0) && Mc6c.DisconFlag == 0)
					{
						TempSpeed.FlData[0] = 0;
						TempSpeed.FlData[1] = 0;
					}
					RecRosDataTimeCnt = 0;
					
					if(Mc6c.LeftKey == 2 || DealTouchFlag == 1)
					{
						return;
					}
			
					SetAddLeftWheelSpeed (TempSpeed.InData[1]);
					SetAddRightWheelSpeed(TempSpeed.InData[2]);
				}
				break;
			}
			case 3:		//�����ͼ�ͣ����
			{
				for(i=0;i<sizeof(RXRobotLedStop.data);i++)
				{
					RXRobotLedStop.data[i] = data[i];
				}
				
				TempCheck =0;
				for(i=0;i<sizeof(RXRobotLedStop.data)-2;i++)
				{
					TempCheck += RXRobotLedStop.data[i];
				}
				
				if(TempCheck != RXRobotLedStop.prot.Check)
				{
					return;
				}
				
//				Led1Mode = RXRobotLedStop.prot.Led12 & 0xff;
//				Led2Mode = (RXRobotLedStop.prot.Led12 >> 8) & 0xff;
				break;
			}
			case 4:		//�س����
			{
				for(i=0;i<sizeof(RXRobotData.data)-2;i++)
				{
					TempCheck += RXRobotData.data[i];
				}
				
				if(TempCheck == RXRobotData.prot.Check)
				{
					//����20ms�ϴ�ģʽ
					ChargeControl = RXRobotData.prot.data;
					
					if(ChargeControl)
					{
						//�����س�
						CanSendONCharge();
					}
					else
					{
						//�رջس�
						CanSendOFFCharge();
					}
				}
				break;
			}
			default:break;
		}
		
	}
	
}
/**************************************************************************
�������ܣ�����ROS���ݳ�ʱ
��ڲ�������
����  ֵ����
**************************************************************************/
u8 ChargeModeFlag=0;
u8 RecRosDataTimeCnt=0;
void DealRosDataTimeOut(void)
{
	if(Mc6c.LeftKey == 2 && Mc6c.DisconFlag == 0)
	{
		//����������ݼ�ʱ
		RecRosDataTimeCnt = 0;
	}
	else
	{
		RecRosDataTimeCnt++;
	}
	
	//������ʱ����ٶ� 1S
	if(RecRosDataTimeCnt > 10)
	{
		RecRosDataTimeCnt = 10;
		SetAddRightWheelSpeed (0);
		SetAddLeftWheelSpeed  (0);
	}
}



