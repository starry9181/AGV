/**
  ******************************************************************************
  * @file    ps.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-08-19
  * @brief   PSң�����ݵĽ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "ps.h"
#include "sys.h" 		
#include "bsp_usart.h"
#include "motor.h"
#include <math.h>
#include <stdlib.h>
#include "control.h"
//////////////////////////////////////////////////////////////////////////////////  

PSBKEY PSBKey;
union PTEMPDATA PTempTxData,PTempRxData;
/**************************************************************************
�������ܣ���ȡң�����ݺ���
��ڲ�������
����  ֵ����ȡ����� 1����ȷ�� 0������
**************************************************************************/
PDEALDATA_RX PDealData_Rx;
static u8 ExtractData(u8 *data)
{
	u8 i;
	s16 TempHead=0;
	u16 ChekSum=0;
	
	TempHead=data[0]+(data[1]<<8);
	if(TempHead==(s16)DATAHEAD )
	{
		
		PDealData_Rx.FrameLength=data[2];  
		PDealData_Rx.ProductType=data[3];
		PDealData_Rx.CMD=(data[4] + (data[5]<<8));          			
		PDealData_Rx.DataNum=data[6];										 		
		switch(PDealData_Rx.DataNum)
		{
			case 1:PTempRxData.InTempData[0]=data[7];break;
			case 2:for(i=0;i<2;i++){PTempRxData.ChTempData[i]=data[7+i];}break;
			case 4:for(i=0;i<4;i++){PTempRxData.ChTempData[i]=data[7+i];}break;
			case 5:for(i=0;i<5;i++){PTempRxData.ChTempData[i]=data[7+i];}break;
			case 6:for(i=0;i<6;i++){PTempRxData.ChTempData[i]=data[7+i];}break;
			case 8:for(i=0;i<8;i++){PTempRxData.ChTempData[i]=data[7+i];}break; 
			case 9:for(i=0;i<9;i++){PTempRxData.ChTempData[i]=data[7+i];}break; 
			default:break;
		}
		PDealData_Rx.CheckSum=(data[PDealData_Rx.FrameLength-1]<<8)+data[PDealData_Rx.FrameLength-2];
		
		for(i=0;i<PDealData_Rx.FrameLength-2;i++)
		{
			ChekSum+=data[i];
		}
		if(ChekSum == PDealData_Rx.CheckSum)
		{
			PDealData_Rx.Success_Flag=1;
			return 1;
		}
		else
		{
			PDealData_Rx.Success_Flag=0;
			return 0;
		}
	}
	return 0;
}

/**************************************************************************
�������ܣ�����ң�����ݺ���
��ڲ�������
����  ֵ����
**************************************************************************/
void DealPSData(void)
{
	s16 speed_RX=0,speed_LY=0; 
	
	speed_LY=(127-PSBKey.PSS_LY)*2.5;
	speed_RX=(PSBKey.PSS_RX-128)*2.5;
	
	if( abs(speed_LY) < 20)
	{
		speed_LY=0;
	}
	if(abs(speed_RX)<20)
	{
		speed_RX=0;
	}
	SetWheelSpeed(&LeftWheel,speed_LY+speed_RX/2);
	//FL_SV_PWM = speed_LY+speed_RX/2;
	FR_SV_PWM = speed_LY-speed_RX/2;
}

/**************************************************************************
�������ܣ��õ�PSң�����ݺ���
��ڲ�������
����  ֵ����
**************************************************************************/
void GetDealPSData(u8 *data)
{
	if(ExtractData(data)){;}
	else{return;}
	switch(PDealData_Rx.CMD)
	{
		case SPSRawData:		//PSԭʼ����
		{
			PSBKey.PSS_LY=PTempRxData.InTempData[0];
			PSBKey.PSS_LX=PTempRxData.InTempData[1];
			PSBKey.PSS_RY=PTempRxData.InTempData[2];
			PSBKey.PSS_RX=PTempRxData.InTempData[3];
		
			switch(PTempRxData.ChTempData[8])
			{
				case PSB_PAD_UP:	PSBKey.UP=1;	break;
				case PSB_PAD_RIGHT: PSBKey.RIGHT=1;	break;
				case PSB_PAD_DOWN: 	PSBKey.DOWN=1;	break;
				case PSB_PAD_LEFT: 	PSBKey.LEFT=1;	break;
				case PSB_L2:		PSBKey.L2=1;	break;
				case PSB_R2:		PSBKey.R2=1;	break;
				case PSB_L1:		PSBKey.L1=1;	break;
				case PSB_R1:		PSBKey.R1=1;	break;
				case PSB_GREEN:		PSBKey.GREEN=1;	break;
				case PSB_RED:		PSBKey.RED=1;	break;
				case PSB_BLUE:		PSBKey.BLUE=1;	break;
				case PSB_PINK:		PSBKey.PINK=1;	break;
			}
			DealPSData();
			break;
		}
		
		default:break;
	}
}

