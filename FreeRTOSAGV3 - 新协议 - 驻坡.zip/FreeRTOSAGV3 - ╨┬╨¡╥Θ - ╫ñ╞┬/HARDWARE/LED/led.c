/**
  ******************************************************************************
  * @file    led.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-12-12
  * @brief   ���������ȿ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "led.h"
#include "main.h"

/**************************************************************************
�������ܣ�״̬�����ų�ʼ��
��ڲ�������
����  ֵ����
**************************************************************************/
void StateLedInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 	GPIO_Init(GPIOD, &GPIO_InitStructure);
	GPIO_SetBits(GPIOD,GPIO_Pin_2);
	
		//����1ģ�⿪�ؿ���
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA.0
	GPIO_ResetBits(GPIOB,GPIO_Pin_3 | GPIO_Pin_4); 
	Y0=0;
	Y1=1;
}

//����˸20ms����
void StateLedDeal(void)
{
	static u8 TimeCnt=0;
	TimeCnt ++;
	//500ms
	if(TimeCnt > 25)
	{
		TimeCnt = 0;
		STALED = ~STALED;
	}
}

/**************************************************************************
�������ܣ�������ų�ʼ��
��ڲ�������
����  ֵ����
**************************************************************************/
void Led_Init(void)
{
                                                 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;				 //LED0-->PB.5 �˿�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	GPIO_Init(GPIOD, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOB.5
	

	
}

u16 ucTM1812EncodeBuffer[TM1812_BUFFER_SIZE] ;

/**************************************************************************
�������ܣ�TM1812�����źŷ�����ʱ��
��ڲ�������
����  ֵ����
**************************************************************************/

static void TIM4_PWM_ModeConfig( void )
{
            
	TIM_TimeBaseInitTypeDef  	TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  			TIM_OCInitStructure;
	GPIO_InitTypeDef 			GPIO_InitStructure;
	DMA_InitTypeDef       		DMA_InitStructure;

	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA1, ENABLE );    
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO, ENABLE );
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM4, ENABLE );

	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_Init( GPIOB, &GPIO_InitStructure );

	TIM_TimeBaseStructure.TIM_Period = 89;                       
	TIM_TimeBaseStructure.TIM_Prescaler = 0;                      
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;                   
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;    
	TIM_TimeBaseInit( TIM4, &TIM_TimeBaseStructure);                

	/* Output Compare Active Mode configuration: Channel1 */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;              
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;   	
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;                              
	TIM_OC1Init( TIM4, &TIM_OCInitStructure );                       

	DMA_DeInit( DMA1_Channel7 );                           
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&TIM4->CCR1;       //ADC�����ַ
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)ucTM1812EncodeBuffer; //�ڴ��ַ
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;                      //���ݴ��䷽��
	DMA_InitStructure.DMA_BufferSize = TM1812_BUFFER_SIZE;                     //�ڴ泤��
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;        //�����ַ����
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;                 //�ڴ��ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; //�������ݿ���  
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;     //�������ݿ���  
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;                         //ѭ������ģʽ
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;                     //DMAͨ��������
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;                            //�ر��ڴ浽�ڴ洫��
	DMA_Init( DMA1_Channel7, &DMA_InitStructure ); 

	DMA_Cmd( DMA1_Channel7, ENABLE ); 
	TIM_DMACmd( TIM4, TIM_DMA_Update, ENABLE );                    
	TIM_Cmd( TIM4, ENABLE );                                         
	
}

/**************************************************************************
�������ܣ�LED��RGB���ú���
��ڲ������Ƶı��  �Ҷ�ֵ���255����λ��
����  ֵ����
**************************************************************************/
void vSetLEDGrayscaleGrade( u8 LED, uint8_t ucGrade )
{
    uint8_t i;
    for( i=0; i<8; i++ )
    {
        
        if( ucGrade & 0x80 )
        {
            ucTM1812EncodeBuffer[LED*8+i] = T1H_IN_850ns;
        }
        else
        {
            ucTM1812EncodeBuffer[LED*8+i] = T0H_IN_400ns;
        }
        ucGrade <<= 1;
        
    }     
}

/**************************************************************************
�������ܣ�TM1812��ʼ������
��ڲ�������
����  ֵ����
**************************************************************************/
void vTM1812Init( void )
{
    uint8_t i; 
	for( i=0;i<TM1812_BUFFER_SIZE;i++ )
    {
        ucTM1812EncodeBuffer[i]=0;     
    }
	
	TIM4_PWM_ModeConfig();
	Led_Init();
	
	vSetLEDGrayscaleGrade(0,0);
	vSetLEDGrayscaleGrade(1,0);
	vSetLEDGrayscaleGrade(2,0);
	vSetLEDGrayscaleGrade(3,0);
	vSetLEDGrayscaleGrade(4,0);
	vSetLEDGrayscaleGrade(5,0);
}

/**************************************************************************
�������ܣ������ƺ��� 50ms����һ��
��ڲ�����mode  4 2 1 λ��Ӧ�� R G B ������ 8��Ӧ���� 0ȫ�ر� 0x0Fȫ����
								
		8 	4 		2 		1			8		4 		2 		1
mode =
		X Blue 	  Green    Red		x 		 LedBlue LedGreen LedRed
				
����  ֵ����
**************************************************************************/
#define PWMADD 1
u8 Led1Mode=0xff;
u8 Led2Mode=0xff;
void LedBreath(void )
{
	static u16	LedPWM1=0,LedPWM2=0;
	static u8	flag1=0,flag2;
	
	if(Led1Mode)
	{
		if(Led1Mode & 0x01)
		{
			if(Led1Mode & 0x10)
			{
				vSetLEDGrayscaleGrade(1,LedPWM1);
			}
			else
			{
				vSetLEDGrayscaleGrade(1,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(1,0);
		}
		
		if(Led1Mode & 0x02)
		{
			if(Led1Mode & 0x20)
			{
				vSetLEDGrayscaleGrade(0,LedPWM1);
			}
			else
			{
				vSetLEDGrayscaleGrade(0,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(0,0);
		}
		
		if(Led1Mode & 0x04)
		{
			if(Led1Mode & 0x40)
			{
				vSetLEDGrayscaleGrade(2,LedPWM1);
			}
			else
			{
				vSetLEDGrayscaleGrade(2,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(2,0);
		}
		
	}
	else
	{
		vSetLEDGrayscaleGrade(0,0);
		vSetLEDGrayscaleGrade(1,0);
		vSetLEDGrayscaleGrade(2,0);
	}
	
	if(LedPWM1 >= 230)
	{
		flag1=1;
	}
	else if(LedPWM1 <= 10)
	{
		flag1=0;
	}

	if(flag1)
	{
		LedPWM1-=PWMADD;
	}
	else
	{
		LedPWM1+=PWMADD;
	}
	
	
	if(Led2Mode)
	{
		if(Led2Mode & 0x01)
		{
			if(Led2Mode & 0x10)
			{
				vSetLEDGrayscaleGrade(4,LedPWM2);
			}
			else
			{
				vSetLEDGrayscaleGrade(4,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(4,0);
		}
		
		if(Led2Mode & 0x02)
		{
			if(Led2Mode & 0x20)
			{
				vSetLEDGrayscaleGrade(3,LedPWM2);
			}
			else
			{
				vSetLEDGrayscaleGrade(3,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(3,0);
		}
		
		if(Led2Mode & 0x04)
		{
			if(Led2Mode & 0x40)
			{
				vSetLEDGrayscaleGrade(5,LedPWM2);
			}
			else
			{
				vSetLEDGrayscaleGrade(5,255);
			}
		}
		else
		{
			vSetLEDGrayscaleGrade(5,0);
		}
		
	}
	else
	{
		vSetLEDGrayscaleGrade(3,0);
		vSetLEDGrayscaleGrade(4,0);
		vSetLEDGrayscaleGrade(5,0);
	}
	
	if(LedPWM2 >= 230)
	{
		flag2=1;
	}
	else if(LedPWM2 <= 10)
	{
		flag2=0;
	}

	if(flag2)
	{
		LedPWM2-=PWMADD;
	}
	else
	{
		LedPWM2+=PWMADD;
	}
}



