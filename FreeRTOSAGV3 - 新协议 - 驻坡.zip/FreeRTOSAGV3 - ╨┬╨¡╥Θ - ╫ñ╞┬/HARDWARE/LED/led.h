#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define STALED  PCout(13)
#define ONUSEPOWER()	GPIO_ResetBits(GPIOD,GPIO_Pin_2)
#define OFFUSEPOWER()	GPIO_SetBits  (GPIOD,GPIO_Pin_2)

#define Y0 PBout(3)
#define Y1 PBout(4)

#define Light1	PBin(9)
#define Light2	PBin(8)
#define Light3	PDin(2)
#define Light4	PCin(12)

#define  TM1812_BUFFER_SIZE  110
#define LIGHT1_GREEN	TIM1->CCR2
#define LIGHT1_BLUE		TIM1->CCR3
#define LIGHT1_RED		TIM1->CCR4

#define LIGHT2_RED		TIM4->CCR1
#define LIGHT2_GREEN	TIM4->CCR2
#define LIGHT2_BLUE		TIM4->CCR3

extern u8 Led1Mode;
extern u8 Led2Mode;

#define T0H_IN_400ns        29
#define T1H_IN_850ns        61


typedef enum {
    BreathRedLED = 0 ,
    BreathGreenLED ,
    BreathBlueLED ,
    RollsWindingLED ,
    WorkModeLED ,    
    BoxCheckLED ,
    WiFiStateLED ,
    BoxFullLED ,
    BatteryChargeLED , 
    Reserve0 ,
    FanErroLED ,
    MotorErroLED ,                   
            
}LEDNumber;

void vTM1812Init( void );
void vSetLEDGrayscaleGrade( u8 LED, uint8_t ucGrade );
void LedBreath(void );
void CanLedNO(void);
void CanLedOFF(void);
void StateLedInit(void);
void StateLedDeal(void);
#endif
