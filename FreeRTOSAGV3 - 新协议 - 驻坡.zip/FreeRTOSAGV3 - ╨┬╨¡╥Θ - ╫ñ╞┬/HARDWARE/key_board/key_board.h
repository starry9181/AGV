#ifndef _KEY_BOARD_H
#define _KEY_BOARD_H
#include "sys.h"


#define  TAKE_GPIO_PINX            GPIO_Pin_10  	//ȡ����
#define  TAKE_GPIOX                GPIOB
#define  TAKE_PINX_STATE_READ      PBin(10)


#define  DISCHARGE_GPIO_PINX       GPIO_Pin_9    //ж����
#define  DISCHARGE_GPIOX           GPIOA
#define  DISCHARGE_PINX_STATE_READ PAin(9)


#define  BATTERY_CHARGE_GPIO_PINX  GPIO_Pin_11    //�����
#define  BATTERY_CHARGE_GPIOX      GPIOB
#define  BATTERY_CHARGE_PINX_STATE_READ    PBin(11)


#define  RESET_GPIO_PINX           GPIO_Pin_10    //��λ
#define  RESET_GPIOX               GPIOA
#define  RESET_PINX_STATE_READ     PAin(10)











#endif

