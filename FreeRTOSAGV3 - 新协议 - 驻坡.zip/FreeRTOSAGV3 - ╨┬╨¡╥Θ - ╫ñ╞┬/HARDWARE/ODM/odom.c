/**
  ******************************************************************************
  * @file    odom.c
  * @author  zxp
  * @version V1.0.0
  * @date    2020-10-15
  * @brief   ��̼Ƽ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "odom.h"
#include "main.h"
//////////////////////////////////////////////////////////////////////////////////  
ODOM Odom;
#define Limit	0x7FFFFFFF
/**************************************************************************
�������ܣ���̼Ƽ��㺯��
��ڲ�����None
����  ֵ��None
**************************************************************************/
void CalculOdom(void)
{
	static u32 LastTimeCount=0;
	float TimeCnt=0;
	TimeCnt = (xTaskGetTickCount() - LastTimeCount)/1000.0;
#if	IMU == 0
	Odom.Vz	= (RightWheel.NowSpeed - LeftWheel. NowSpeed)*1.0f / WHEELBASEX;
	
	Odom.Yaw +=	Odom.Vz *TimeCnt;
	
//	if(Odom.Yaw >  PI){Odom.Yaw = -PI+( Odom.Yaw - PI);}
//	if(Odom.Yaw < -PI){Odom.Yaw =  PI+(-Odom.Yaw + PI);}

#elif IMU == 1
	
	Odom.Vz	=	stcGyro.w[2]/32768.0*2000/180.0*PI;
	
	Odom.Yaw +=	Odom.Vz *TimeCnt;
	
//	Odom.Yaw=	stcAngle.Angle[2]/32768.0*PI;
#endif
	
	Odom.Vx = (LeftWheel. NowSpeed + RightWheel.NowSpeed) / 2.0f;
	Odom.TempX = Odom.Vx * TimeCnt * cos(Odom.Yaw);
	Odom.TempY = Odom.Vx * TimeCnt * sin(Odom.Yaw);
	
	Odom.X += Odom.TempX;
	Odom.Y += Odom.TempY;
	LastTimeCount = xTaskGetTickCount();
	
}
