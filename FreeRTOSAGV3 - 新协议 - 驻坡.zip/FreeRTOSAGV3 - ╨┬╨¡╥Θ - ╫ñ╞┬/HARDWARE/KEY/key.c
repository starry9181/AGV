/**
  ******************************************************************************
  * @file    key.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-12-12
  * @brief   ң�����������
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "key.h"
#include "sys.h"
#include "magnetic.h"
#include "control.h"
#include "led.h"
#include "bsp_usart.h"
#include "buildmap.h"
#include "magnetic.h"
//////////////////////////////////////////////////////////////////////////////////  
								    
/**************************************************************************
�������ܣ�ң�����������ų�ʼ��
��ڲ�����None
����  ֵ��None
**************************************************************************/
void KEY_Init(void) //IO��ʼ��
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO,ENABLE );//ʹ��PORTA,PORTEʱ��
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 
	
	//D4-5
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIOA.0
	
	//D0-3 
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA.0
	
	//M0 M1
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA.0
	GPIO_ResetBits(GPIOB,GPIO_Pin_1 | GPIO_Pin_2); 
	
	//����1ģ�⿪�ؿ���
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA.0
	GPIO_ResetBits(GPIOB,GPIO_Pin_3 | GPIO_Pin_4); 
	Y0=0;
	Y1=0;
	//Light1 light2
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13 | GPIO_Pin_12;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 
//	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA.0

}

/**************************************************************************
�������ܣ�����һģ�⿪��ѡ��
��ڲ�����None
����  ֵ��None
**************************************************************************/
void USART1Choice(u8 mode)
{
	switch(mode)
	{
		case 0:
		{
			GPIO_ResetBits(GPIOC,GPIO_Pin_4 | GPIO_Pin_5); 
			break;
		}
		case 1:
		{
			GPIO_ResetBits(GPIOC,GPIO_Pin_5); 
			GPIO_SetBits(GPIOC,GPIO_Pin_4);
			break;
		}
		default:break;
	}
}

/**************************************************************************
�������ܣ�ң��������ɨ��
��ڲ�����None
����  ֵ��None
**************************************************************************/
void RemoteControlScan(void)
{
	static u8 KeyFlag=0,TimeCnt=0;
	if(NUM1)
	{
		//����ģʽ�²��ɿ�
		if(Magnetic.RunStaus==1)
		{
			return;
		}
		SetAddLeftWheelSpeed(500);
		SetAddRightWheelSpeed(500);
		KeyFlag=1;
	}
	else if(NUM2)
	{
		if(Magnetic.RunStaus==1)
		{
			return;
		}
		SetAddLeftWheelSpeed(-500);
		SetAddRightWheelSpeed(-500);
		KeyFlag=1;
	}
	else if(NUM3)
	{
		if(Magnetic.RunStaus==1)
		{
			return;
		}
		SetAddLeftWheelSpeed(-120);
		SetAddRightWheelSpeed(120);
		KeyFlag=1;
	}
	else if(NUM4)
	{
		if(Magnetic.RunStaus==1)
		{
			return;
		}
		SetAddLeftWheelSpeed(120);
		SetAddRightWheelSpeed(-120);
		KeyFlag=1;
	}
	else if(NUM5)
	{
		if(TimeCnt == 0)
		{
			if(Magnetic.RunStaus==0)
			{
//				RUNMagnetic();	
//				TheWayCharge();
				TimeCnt =50;
			}
			else
			{
				STOPMagnetic();
				TimeCnt =50;
			}
		}
	}
	else if(NUM6)
	{
		if(TimeCnt == 0)
		{
			if(Magnetic.ChargeModeFlag == 0)
			{
				RUNCharge(100);
				TimeCnt =50;
			}
			else
			{
				STOPCharge();
				TimeCnt =50;
			}
		}
	}
	//�ٶ���0
	else if(KeyFlag==1)
	{
		SetAddLeftWheelSpeed(0);
		SetAddRightWheelSpeed(0);
		KeyFlag = 0;
	}
	else
	{
		if(TimeCnt)
		{
			TimeCnt--;
		}
	}
}
