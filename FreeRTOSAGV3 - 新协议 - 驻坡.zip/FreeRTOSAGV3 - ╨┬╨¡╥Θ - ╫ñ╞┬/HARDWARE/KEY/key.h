#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
//////////////////////////////////////////////////////////////////////////////////	 								  
//////////////////////////////////////////////////////////////////////////////////   	 
#define NUM2 PBin(12)
#define NUM3 PBin(13)
#define NUM1 PBin(14)
#define NUM4 PBin(15)
#define NUM5 PCin(6)
#define NUM6 PCin(7)

#define LIGHT1 PBin(12)
#define LIGHT2 PBin(13)

#define M0 PBout(2)
#define M1 PBout(1)
#define AUX PBin(0)

#define Y0 PBout(3)
#define Y1 PBout(4)


typedef union 
{
	u8   ChData[8];
	s16  InDatal[4];
}TEMPCANDATA;

void KEY_Init(void);//IO��ʼ��	
void RemoteControlScan(void);//ң����ɨ��

void CanForward(u16 speed);
void CanBack(u16 speed);
void CanTurnLeht(u16 speed);
void CanTurnRight(u16 speed);
void CanToZeroSpeed(void);
void USART1Choice(u8 mode);
#endif
