#ifndef __ERRORDETECT_H
#define __ERRORDETECT_H	 
#include "sys.h"

extern union ROBOTSTATE
{
	struct bit_feild
	{
			char bit0: 1;  
			char bit1: 1;  
			char bit2: 1;  
			char bit3: 1;  
			char bit4: 1;  
			char bit5: 1;  
			char bit6: 1;  
			char bit7: 1;  
			char bit8: 1;  
			char bit9: 1;
			char bit10:1;
			char bit11:1;
			char bit12:1;
			char bit13:1;
			char bit14:1;
			char bit15:1;
	} bits;
	s16 data;
}RobotState;

extern _Bool DealTouchFlag;

void Init_ErrorDetect(void);
void ErrorDetect(void);
void DealTouch(void);
void LightCon(void);
#endif
