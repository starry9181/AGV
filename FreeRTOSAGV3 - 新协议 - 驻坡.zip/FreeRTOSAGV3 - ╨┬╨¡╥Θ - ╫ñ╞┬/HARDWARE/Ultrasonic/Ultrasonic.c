/**
  ******************************************************************************
  * @file    ps.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-12-23
  * @brief   ���������ݽ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "ultrasonic.h"
#include "main.h"
//////////////////////////////////////////////////////////////////////////////////  


//���ͳ���������250ms����һ��
void SendUltrasonicCMD(u8 num)
{
	static u8 CMD[5]={0x55,0xAA,0x01,0x01,0x01};
	switch(num)
	{
		case 0:
		{
			CMD[3]=ULTR_All;
			break;
		}
		case 1:
		{
			CMD[3]=ULTR_One;
			break;
		}
		case 2:
		{
			CMD[3]=ULTR_Two;
			break;
		}
		case 3:
		{
			CMD[3]=ULTR_Three;
			break;
		}
		case 4:
		{
			CMD[3]=ULTR_Four;
			break;
		}
		default: break; 
	}
	USART3_DMA_TX(CMD,5);	 
}

ULTR Ultr;
void GetUltrasonicData(u8 *data)
{
	u8 i=0,UltrNum=0;
	u8 CheckSum=0;
	if(data[0] == 0x55 && data[1] == 0xAA)
	{
		if(data[2] == ULTR_ADDR )
		{
			switch(data[3])
			{
				case ULTR_All:
				{
					UltrNum=4;
					Ultr.U1=(data[4]<<8)+data[5];
					Ultr.U2=(data[6]<<8)+data[7];
					Ultr.U3=(data[8]<<8)+data[9];
					Ultr.U4=(data[10]<<8)+data[11];
					//�����Ϊ��Զ
					if(Ultr.U1 == 0){Ultr.U1 = 3000;}
					if(Ultr.U2 == 0){Ultr.U2 = 3000;}
					if(Ultr.U3 == 0){Ultr.U3 = 3000;}
					if(Ultr.U4 == 0){Ultr.U4 = 3000;}
					break;
				}
				case ULTR_One:
				{
					UltrNum=1;
					Ultr.U1=(data[4]<<8)+data[5];
					break;
				}
				case ULTR_Two:
				{
					UltrNum=1;
					Ultr.U2=(data[4]<<8)+data[5];
					break;
				}
				case ULTR_Three:
				{
					UltrNum=1;
					Ultr.U3=(data[4]<<8)+data[5];
					break;
				}
				case ULTR_Four:
				{
					UltrNum=1;
					Ultr.U4=(data[4]<<8)+data[5];
					break;
				}
				default: break;
			}
			
			
			//checksum У��
			for(i=0;i<UltrNum*2+5-1;i++)
			{
				CheckSum += data[i];
			}
			if(CheckSum != data[UltrNum*2+5-1])
			{
				Ultr.U1=0;
				Ultr.U2=0;
				Ultr.U3=0;
				Ultr.U4=0;
				Ultr.Ultr_RXFlag=0;  //����ʧ��
			}
			else
			{
				Ultr.Ultr_RXFlag=1;  //���ճɹ�
			}
		}
	}
}

