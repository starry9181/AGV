#ifndef __BSP_USART_H
#define __BSP_USART_H
#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "semphr.h"
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define MAX_RX_CNT 100
#define EXCNT1 5	//��ά���鳤��1
#define EXCNT2 30	//��ά���鳤��2
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern u8 USART1_Rx_Buff[MAX_RX_CNT];
extern u8 USART2_Rx_Buff[MAX_RX_CNT];
extern u8 USART3_Rx_Buff[MAX_RX_CNT];
extern u8 UART4_Rx_Buff[MAX_RX_CNT];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void USART1_Config(uint32_t BaudRate);
void USART2_Config(uint32_t BaudRate);
void USART3_Config(uint32_t BaudRate);
void UART4_Config(uint32_t BaudRate);

void u1_printf(const char *format,...);
void u2_printf(const char *format,...);
void u3_printf(const char *format,...);
void u4_printf(const char *format,...);
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
uint8_t USART1_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt);
uint8_t USART2_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt);
uint8_t USART3_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt);
uint8_t UART4_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt);
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void Task6(void *pvParameters);
void Task7(void *pvParameters);
void Task8(void *pvParameters);
void Task9(void *pvParameters);

#endif

